import joblib
from  flask import Flask,render_template,request,redirect
app = Flask(__name__)
@app.route('/')
def home():
    return render_template('Home_1.html')

@app.route('/Predict',methods=['GET','POST'])
def prediction():
    return render_template('Index.html')

@app.route('/form',methods=['GET','POST'])
def brain():
    
    Nitrogen=float(request.form['Nitrogen'])
    Phosphorus=float(request.form['Phosphorus'])
    Potassium=float(request.form['Potassium'])
    Temperature=float(request.form['Temperature'])
    Humidity=float(request.form['Humidity'])
    Ph=float(request.form['Ph'])
    Rainfall=float(request.form['Rainfall'])

    values=[Nitrogen,Phosphorus,Potassium,Temperature,Humidity,Ph,Rainfall]

    if Ph>0 and Ph<14 and Temperature<100 and Humidity>0:
        joblib.load('crop_app','r')
        model=joblib.load(open('crop_app','rb'))
        arr=[values] 
        acc=model.predict(arr)
        # print(acc)
        return render_template('prediction.html',prediction=str(acc))
    else:
        return "Sorry.... Error in the entered values in the form.Please check the values and fill it."
    

    if request.method == 'POST': 
        try: 
            Ph = float(request.form['Ph']) 
            # Load the model file 
            model = joblib.load('crop_model.pkl') 
            # Further processing here
        except FileNotFoundError: 
            return "Model file not found", 500 
        except KeyError as e: 
            return f"Missing form field: {e}",400
    return render_template('prediction.html')    

if __name__=='__main__':
    app.run(debug=True)    



